<?php
/**
 * template name: Our works
 */
get_header()?>

<div class="work-wrap">
    <div class="container rWorks">
        
    <div class = "rWork-text"><?php echo get_field('text') ?></div>
    
    <div class = "row">
    <?php
    $args = array(
        'post_type'      => 'Work', 
        'posts_per_page' => -1, 
        'orderby'        => 'date',
        'order'          => 'DESC', 
    );
    
    $query = new WP_Query($args);
    
    if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();?>
        
        
           <div class="work-post">
                <div class = "col-lg-6">
                    <div class = "work-img">
                        <?php the_post_thumbnail()?>
                    </div>
                </div>
                <div class = "col-lg-6">
                    <div class = "work-cate">
                       <?php
                        // var_dump(get_the_terms(get_the_ID(), 'work_categories'));
                        echo get_the_terms(get_the_ID(), 'work_categories')[0]->name;
                        ?>
                    </div>
                    <div class = "work-title">
                        <?php the_title() ?>
                    </div>
                    <a class="learn-more" href="<?php the_permalink()?>">View more</a>
                </div>
           </div>
        
            
         <?php endwhile;
        wp_reset_postdata();
    else :
        echo 'No posts found';
    endif;
    ?>
    </div>
</div>
</div>

<div class="message-block">
        <div class="idea-message">
            <?php  echo get_field('idea_message','option')?>
        </div>
        <a class="learn-more i-message"
            href="<?php  echo get_field('send_message_link','option')?>"><?php  echo get_field('idea_btn_text','option')?></a>
    </div>





<?php get_footer() ?>