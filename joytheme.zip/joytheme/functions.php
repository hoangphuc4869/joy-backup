<?php
function m_register_menu()
{
	register_nav_menus(
		array(
			'menu-1' => __('Menu PC'),
			'menu-2' => __('Menu Mobile'),
			
		)
	);
}
add_action('init', 'm_register_menu');

function add_favicon() {
  echo '<link rel="shortcut icon" type="image/png" href="https://joycreators.vn/wp-content/uploads/2023/10/logo-joy.png" />';
}
 
add_action('wp_head', 'add_favicon');



add_filter( 'show_admin_bar', '__return_false' );


add_theme_support('post-thumbnails');

if (function_exists('acf_add_options_page')) {
    acf_add_options_page();
}

add_action('init', 'work_register');
function work_register() {

    $labels = array(
        'name' => 'Work',
        'singular_name' => 'Work',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Work',
        'edit_item' => 'Edit Work',
        'new_item' => 'New Work',
        'view_item' => 'View Work',
        'search_items' => 'Search Work',
        'not_found' =>  'Nothing found',
        'not_found_in_trash' => 'Nothing found in Trash',
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => false,// Cho phép phân cấp - mặc định post là false và page là true
		'menu_icon' => 'dashicons-grid-view',
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'has_archive' => true,
        'rewrite' => array( 'slug' => 'work', 'with_front' => true ),
        'capability_type' => 'post',
        'menu_position' => 6,
        'supports' => array('title', 'excerpt','author','comments','editor','thumbnail','custom-fields','revisions','trackbacks')
      );

    register_post_type( 'Work' , $args );
}

add_action('init', 'work_categories_register');

function work_categories_register() {
$labels = array(
    'name'                          => 'Work Categories',
    'singular_name'                 => 'Work Category',
    'search_items'                  => 'Search Work Categories',
    'popular_items'                 => 'Popular Work Categories',
    'all_items'                     => 'All Work Categories',
    'parent_item'                   => 'Parent Work Category',
    'edit_item'                     => 'Edit Work Category',
    'update_item'                   => 'Update Work Category',
    'add_new_item'                  => 'Add New Work Category',
    'new_item_name'                 => 'New Work Category',
    'separate_items_with_commas'    => 'Separate Work categories with commas',
    'add_or_remove_items'           => 'Add or remove Work categories',
    'choose_from_most_used'         => 'Choose from most used Work categories'
    );

$args = array(
    'label'                         => 'Work Categories',
    'labels'                        => $labels,
    'public'                        => true,
    'hierarchical'                  => true,
    'show_ui'                       => true,
    'show_in_nav_menus'             => true,
    'args'                          => array( 'orderby' => 'term_order' ),
    'rewrite'                       => array( 'slug' => 'work_categories', 'with_front' => true, 'hierarchical' => true ),
    'query_var'                     => true
);

register_taxonomy( 'work_categories', 'work', $args );
}