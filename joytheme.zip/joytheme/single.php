<?php get_header() ?>

<div class="content">
    <div class="container">
        <div class="row">
            <h3 class="title-single"><?php the_title(); ?></h3>
            <div class="content-single"><?php the_content(); ?></div>
        </div>
    </div>
</div>

<?php get_footer() ?>