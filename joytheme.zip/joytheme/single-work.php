<?php get_header() ?>


    <div class="sing-wrap">
        <div class="container">
        <div class="sing-title" >
            <?php the_title() ?>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="project-scope">
                    <div class="pro-text"><?php echo get_field('pro-text') ?></div>
                    <ol class="list-project">
                     <?php if(have_rows('project-scope')): while(have_rows('project-scope')): the_row(); ?>
                        
                            <li class="scope-item"><span><?php echo get_sub_field('text') ?></span></li>
                        
                        <?php endwhile; endif; ?>
                    </ol>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="sing-excerpt" ><?php the_excerpt() ?></div>
            </div>
            
        </div>
        <div class="sing-img"><?php the_post_thumbnail() ?></div>
        <div class="sing-content"><?php the_content() ?></div>
    </div>
    </div>
    <div class="message-block">
        <div class="idea-message">
            <?php  echo get_field('idea_message','option')?>
        </div>
        <a class="learn-more i-message"
            href="<?php  echo get_field('send_message_link','option')?>"><?php  echo get_field('idea_btn_text','option')?></a>
    </div>


<?php get_footer() ?>